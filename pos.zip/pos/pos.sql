-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-08-2025 a las 03:48:15
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `categoria` text COLLATE utf8_spanish_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `categoria`, `fecha`) VALUES
(6, 'Películas', '2025-08-08 00:35:08'),
(7, 'Terror', '2025-08-08 00:44:58'),
(8, 'Comedia', '2025-08-08 00:45:09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` text COLLATE utf8_spanish_ci NOT NULL,
  `documento` int(11) NOT NULL,
  `email` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` text COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `compras` int(11) NOT NULL,
  `ultima_compra` datetime NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `documento`, `email`, `telefono`, `direccion`, `fecha_nacimiento`, `compras`, `ultima_compra`, `fecha`) VALUES
(3, 'Juan Villegas', 2147483647, 'juan@hotmail.com', '(300) 341-2345', 'Calle 23 # 45 - 56', '1980-11-02', 7, '2018-02-06 17:47:02', '2018-02-06 22:47:02'),
(4, 'Pedro Pérez', 2147483647, 'pedro@gmail.com', '(399) 876-5432', 'Calle 34 N33 -56', '1970-08-07', 7, '2017-12-26 17:27:42', '2017-12-26 22:27:42'),
(5, 'Miguel Murillo', 325235235, 'miguel@hotmail.com', '(254) 545-3446', 'calle 34 # 34 - 23', '1976-03-04', 32, '2017-12-26 17:27:13', '2017-12-27 04:38:13'),
(6, 'Margarita Londoño', 34565432, 'margarita@hotmail.com', '(344) 345-6678', 'Calle 45 # 34 - 56', '1976-11-30', 14, '2017-12-26 17:26:51', '2017-12-26 22:26:51'),
(7, 'Julian Ramirez', 786786545, 'julian@hotmail.com', '(675) 674-5453', 'Carrera 45 # 54 - 56', '1980-04-05', 14, '2017-12-26 17:26:28', '2017-12-26 22:26:28'),
(8, 'Stella Jaramillo', 65756735, 'stella@gmail.com', '(435) 346-3463', 'Carrera 34 # 45- 56', '1956-06-05', 9, '2017-12-26 17:25:55', '2017-12-26 22:25:55'),
(9, 'Eduardo López', 2147483647, 'eduardo@gmail.com', '(534) 634-6565', 'Carrera 67 # 45sur', '1978-03-04', 12, '2017-12-26 17:25:33', '2017-12-26 22:25:33'),
(10, 'Ximena Restrepo', 436346346, 'ximena@gmail.com', '(543) 463-4634', 'calle 45 # 23 - 45', '1956-03-04', 18, '2017-12-26 17:25:08', '2017-12-26 22:25:08'),
(11, 'David Guzman', 43634643, 'david@hotmail.com', '(354) 574-5634', 'carrera 45 # 45 ', '1967-05-04', 10, '2017-12-26 17:24:50', '2017-12-26 22:24:50'),
(12, 'Gonzalo Pérez', 436346346, 'gonzalo@yahoo.com', '(235) 346-3464', 'Carrera 34 # 56 - 34', '1967-08-09', 24, '2017-12-25 17:24:24', '2017-12-27 00:30:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `codigo` text COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `imagen` text COLLATE utf8_spanish_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `precio_compra` float NOT NULL,
  `precio_venta` float NOT NULL,
  `ventas` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `id_categoria`, `codigo`, `descripcion`, `imagen`, `stock`, `precio_compra`, `precio_venta`, `ventas`, `fecha`) VALUES
(1, 0, 'Inception', 'Leonardo DiCaprio', 'Christopher Nolan', 20, 4500, 6300, 1, '2025-08-08 00:47:14'),
(2, 0, 'Titanic', 'Leonardo DiCaprio', 'James Cameron', 20, 3000, 4200, 1, '2025-08-08 00:43:46'),
(3, 1, 'The Godfather', 'Marlon Brando', 'Francis Ford Coppola', 20, 4000, 5600, 1, '2025-08-08 00:26:45'),
(4, 1, 'Pulp Fiction', 'John Travolta', 'Quentin Tarantino', 20, 1540, 2156, 1, '2025-08-08 00:26:45'),
(5, 1, 'Forrest Gump', 'Tom Hanks', 'Robert Zemeckis', 20, 1100, 1540, 1, '2025-08-08 00:26:45'),
(6, 1, 'The Dark Knight', 'Christian Bale', 'Christopher Nolan', 20, 1540, 2156, 1, '2025-08-08 00:26:45'),
(7, 1, 'Gladiator', 'Russell Crowe', 'Ridley Scott', 20, 1540, 2156, 1, '2025-08-08 00:26:45'),
(8, 1, 'Avatar', 'Sam Worthington', 'James Cameron', 20, 2600, 3640, 1, '2025-08-08 00:26:45'),
(9, 1, 'The Shawshank Redemption', 'Tim Robbins', 'Frank Darabont', 20, 2210, 3094, 1, '2025-08-08 00:26:45'),
(10, 1, 'Jurassic Park', 'Sam Neill', 'Steven Spielberg', 20, 2860, 4004, 1, '2025-08-08 00:26:45'),
(11, 1, 'Star Wars', 'Mark Hamill', 'George Lucas', 20, 2400, 3360, 1, '2025-08-08 00:26:45'),
(12, 1, 'The Matrix', 'Keanu Reeves', 'Lana Wachowski', 20, 1100, 1540, 1, '2025-08-08 00:26:45'),
(13, 1, 'Fight Club', 'Brad Pitt', 'David Fincher', 20, 4500, 6300, 1, '2025-08-08 00:26:45'),
(14, 1, 'Interstellar', 'Matthew McConaughey', 'Christopher Nolan', 20, 1980, 2772, 1, '2025-08-08 00:26:45'),
(15, 1, 'The Silence of the Lambs', 'Jodie Foster', 'Jonathan Demme', 20, 4200, 5880, 1, '2025-08-08 00:26:45'),
(16, 1, 'Saving Private Ryan', 'Tom Hanks', 'Steven Spielberg', 20, 1800, 2520, 1, '2025-08-08 00:26:45'),
(17, 1, 'The Lord of the Rings: The Fellowship of the Ring', 'Elijah Wood', 'Peter Jackson', 20, 5600, 7840, 1, '2025-08-08 00:26:45'),
(18, 1, 'The Lion King', 'Matthew Broderick', 'Roger Allers', 20, 9600, 13440, 1, '2025-08-08 00:26:45'),
(19, 1, 'Back to the Future', 'Michael J. Fox', 'Robert Zemeckis', 20, 3850, 5390, 1, '2025-08-08 00:26:45'),
(20, 1, 'E.T.', 'Henry Thomas', 'Steven Spielberg', 20, 9600, 13440, 1, '2025-08-08 00:26:45'),
(21, 0, 'Inception', 'Leonardo DiCaprio', 'Christopher Nolan', 20, 4500, 6300, 1, '2025-08-08 00:47:14'),
(22, 0, 'Titanic', 'Leonardo DiCaprio', 'James Cameron', 20, 3000, 4200, 1, '2025-08-08 00:43:46'),
(23, 1, 'The Godfather', 'Marlon Brando', 'Francis Ford Coppola', 20, 4600, 6440, 1, '2025-08-08 00:26:45'),
(24, 1, 'Pulp Fiction', 'John Travolta', 'Quentin Tarantino', 20, 1440, 2016, 1, '2025-08-08 00:26:45'),
(25, 1, 'Forrest Gump', 'Tom Hanks', 'Robert Zemeckis', 20, 1600, 2240, 1, '2025-08-08 00:26:45'),
(26, 1, 'The Dark Knight', 'Christian Bale', 'Christopher Nolan', 20, 900, 1260, 1, '2025-08-08 00:26:45'),
(27, 1, 'Gladiator', 'Russell Crowe', 'Ridley Scott', 20, 100, 140, 1, '2025-08-08 00:26:45'),
(28, 1, 'Avatar', 'Sam Worthington', 'James Cameron', 20, 162, 226, 1, '2025-08-08 00:26:45'),
(29, 1, 'The Shawshank Redemption', 'Tim Robbins', 'Frank Darabont', 20, 270, 378, 1, '2025-08-08 00:26:45'),
(30, 1, 'Jurassic Park', 'Sam Neill', 'Steven Spielberg', 20, 75, 105, 1, '2025-08-08 00:26:45'),
(31, 1, 'Star Wars', 'Mark Hamill', 'George Lucas', 20, 168, 235, 1, '2025-08-08 00:26:45'),
(32, 1, 'The Matrix', 'Keanu Reeves', 'Lana Wachowski', 20, 1750, 2450, 1, '2025-08-08 00:26:45'),
(33, 1, 'Fight Club', 'Brad Pitt', 'David Fincher', 20, 175, 245, 1, '2025-08-08 00:26:45'),
(34, 1, 'Interstellar', 'Matthew McConaughey', 'Christopher Nolan', 20, 420, 588, 1, '2025-08-08 00:26:45'),
(35, 1, 'The Silence of the Lambs', 'Jodie Foster', 'Jonathan Demme', 20, 3500, 4900, 1, '2025-08-08 00:26:45'),
(36, 1, 'Saving Private Ryan', 'Tom Hanks', 'Steven Spielberg', 20, 3550, 4970, 1, '2025-08-08 00:26:45'),
(37, 1, 'The Lord of the Rings: The Fellowship of the Ring', 'Elijah Wood', 'Peter Jackson', 20, 3600, 5040, 1, '2025-08-08 00:26:45'),
(38, 1, 'The Lion King', 'Matthew Broderick', 'Roger Allers', 20, 3650, 5110, 1, '2025-08-08 00:26:45'),
(39, 1, 'Back to the Future', 'Michael J. Fox', 'Robert Zemeckis', 20, 3700, 5180, 1, '2025-08-08 00:26:45'),
(40, 1, 'E.T.', 'Henry Thomas', 'Steven Spielberg', 20, 3750, 5250, 1, '2025-08-08 00:26:45'),
(41, 0, 'Inception', 'Leonardo DiCaprio', 'Christopher Nolan', 20, 4500, 6300, 1, '2025-08-08 00:47:14'),
(42, 0, 'Titanic', 'Leonardo DiCaprio', 'James Cameron', 20, 3000, 4200, 1, '2025-08-08 00:43:46'),
(43, 1, 'The Godfather', 'Marlon Brando', 'Francis Ford Coppola', 20, 350, 490, 1, '2025-08-08 00:26:45'),
(44, 1, 'Pulp Fiction', 'John Travolta', 'Quentin Tarantino', 20, 370, 518, 1, '2025-08-08 00:26:45'),
(45, 1, 'Forrest Gump', 'Tom Hanks', 'Robert Zemeckis', 20, 380, 532, 1, '2025-08-08 00:26:45'),
(46, 1, 'The Dark Knight', 'Christian Bale', 'Christopher Nolan', 20, 380, 532, 1, '2025-08-08 00:26:45'),
(47, 1, 'Gladiator', 'Russell Crowe', 'Ridley Scott', 20, 480, 672, 1, '2025-08-08 00:26:45'),
(48, 1, 'Avatar', 'Sam Worthington', 'James Cameron', 20, 600, 840, 1, '2025-08-08 00:26:45'),
(49, 1, 'The Shawshank Redemption', 'Tim Robbins', 'Frank Darabont', 20, 900, 1260, 1, '2025-08-08 00:26:45'),
(50, 1, 'Jurassic Park', 'Sam Neill', 'Steven Spielberg', 20, 100, 140, 1, '2025-08-08 00:26:45'),
(51, 1, 'Star Wars', 'Mark Hamill', 'George Lucas', 20, 130, 182, 1, '2025-08-08 00:26:45'),
(52, 1, 'The Matrix', 'Keanu Reeves', 'Lana Wachowski', 20, 770, 1078, 1, '2025-08-08 00:26:45'),
(53, 1, 'Fight Club', 'Brad Pitt', 'David Fincher', 20, 660, 924, 1, '2025-08-08 00:26:45'),
(54, 1, 'Interstellar', 'Matthew McConaughey', 'Christopher Nolan', 20, 400, 560, 1, '2025-08-08 00:26:45'),
(55, 1, 'The Silence of the Lambs', 'Jodie Foster', 'Jonathan Demme', 20, 450, 630, 1, '2025-08-08 00:26:45'),
(56, 1, 'Saving Private Ryan', 'Tom Hanks', 'Steven Spielberg', 20, 580, 812, 1, '2025-08-08 00:26:45'),
(57, 1, 'The Lord of the Rings: The Fellowship of the Ring', 'Elijah Wood', 'Peter Jackson', 20, 420, 588, 1, '2025-08-08 00:26:45'),
(58, 1, 'The Lion King', 'Matthew Broderick', 'Roger Allers', 20, 140, 196, 1, '2025-08-08 00:26:45'),
(59, 1, 'Back to the Future', 'Michael J. Fox', 'Robert Zemeckis', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(60, 1, 'E.T.', 'Henry Thomas', 'Steven Spielberg', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(61, 0, 'Inception', 'Leonardo DiCaprio', 'Christopher Nolan', 20, 4500, 6300, 1, '2025-08-08 00:47:14'),
(62, 0, 'Titanic', 'Leonardo DiCaprio', 'James Cameron', 20, 3000, 4200, 1, '2025-08-08 00:43:46'),
(63, 1, 'The Godfather', 'Marlon Brando', 'Francis Ford Coppola', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(64, 1, 'Pulp Fiction', 'John Travolta', 'Quentin Tarantino', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(65, 1, 'Forrest Gump', 'Tom Hanks', 'Robert Zemeckis', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(66, 1, 'The Dark Knight', 'Christian Bale', 'Christopher Nolan', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(67, 1, 'Gladiator', 'Russell Crowe', 'Ridley Scott', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(68, 1, 'Avatar', 'Sam Worthington', 'James Cameron', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(69, 1, 'The Shawshank Redemption', 'Tim Robbins', 'Frank Darabont', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(70, 1, 'Jurassic Park', 'Sam Neill', 'Steven Spielberg', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(71, 1, 'Star Wars', 'Mark Hamill', 'George Lucas', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(72, 1, 'The Matrix', 'Keanu Reeves', 'Lana Wachowski', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(73, 1, 'Fight Club', 'Brad Pitt', 'David Fincher', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(74, 1, 'Interstellar', 'Matthew McConaughey', 'Christopher Nolan', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(75, 1, 'The Silence of the Lambs', 'Jodie Foster', 'Jonathan Demme', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(76, 1, 'Saving Private Ryan', 'Tom Hanks', 'Steven Spielberg', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(77, 1, 'The Lord of the Rings: The Fellowship of the Ring', 'Elijah Wood', 'Peter Jackson', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(78, 1, 'The Lion King', 'Matthew Broderick', 'Roger Allers', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(79, 1, 'Back to the Future', 'Michael J. Fox', 'Robert Zemeckis', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(80, 1, 'E.T.', 'Henry Thomas', 'Steven Spielberg', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(81, 0, 'Inception', 'Leonardo DiCaprio', 'Christopher Nolan', 20, 4500, 6300, 1, '2025-08-08 00:47:14'),
(82, 0, 'Titanic', 'Leonardo DiCaprio', 'James Cameron', 20, 3000, 4200, 1, '2025-08-08 00:43:46'),
(83, 1, 'The Godfather', 'Marlon Brando', 'Francis Ford Coppola', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(84, 1, 'Pulp Fiction', 'John Travolta', 'Quentin Tarantino', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(85, 1, 'Forrest Gump', 'Tom Hanks', 'Robert Zemeckis', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(86, 1, 'The Dark Knight', 'Christian Bale', 'Christopher Nolan', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(87, 1, 'Gladiator', 'Russell Crowe', 'Ridley Scott', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(88, 1, 'Avatar', 'Sam Worthington', 'James Cameron', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(89, 1, 'The Shawshank Redemption', 'Tim Robbins', 'Frank Darabont', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(90, 1, 'Jurassic Park', 'Sam Neill', 'Steven Spielberg', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(91, 1, 'Star Wars', 'Mark Hamill', 'George Lucas', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(92, 1, 'The Matrix', 'Keanu Reeves', 'Lana Wachowski', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(93, 1, 'Fight Club', 'Brad Pitt', 'David Fincher', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(94, 1, 'Interstellar', 'Matthew McConaughey', 'Christopher Nolan', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(95, 1, 'The Silence of the Lambs', 'Jodie Foster', 'Jonathan Demme', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(96, 1, 'Saving Private Ryan', 'Tom Hanks', 'Steven Spielberg', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(97, 1, 'The Lord of the Rings: The Fellowship of the Ring', 'Elijah Wood', 'Peter Jackson', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(98, 1, 'The Lion King', 'Matthew Broderick', 'Roger Allers', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(99, 1, 'Back to the Future', 'Michael J. Fox', 'Robert Zemeckis', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(100, 1, 'E.T.', 'Henry Thomas', 'Steven Spielberg', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(101, 0, 'Inception', 'Leonardo DiCaprio', 'Christopher Nolan', 20, 4500, 6300, 1, '2025-08-08 00:47:14'),
(102, 0, 'Titanic', 'Leonardo DiCaprio', 'James Cameron', 20, 3000, 4200, 1, '2025-08-08 00:43:46'),
(103, 1, 'The Godfather', 'Marlon Brando', 'Francis Ford Coppola', 20, 930, 1302, 1, '2025-08-08 00:26:45'),
(104, 1, 'Pulp Fiction', 'John Travolta', 'Quentin Tarantino', 20, 930, 1302, 1, '2025-08-08 00:26:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` text COLLATE utf8_spanish_ci NOT NULL,
  `usuario` text COLLATE utf8_spanish_ci NOT NULL,
  `password` text COLLATE utf8_spanish_ci NOT NULL,
  `perfil` text COLLATE utf8_spanish_ci NOT NULL,
  `foto` text COLLATE utf8_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `ultimo_login` datetime NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `usuario`, `password`, `perfil`, `foto`, `estado`, `ultimo_login`, `fecha`) VALUES
(1, 'Administrador', 'admin', 'admin', 'Administrador', 'vistas/img/usuarios/admin/191.jpg', 1, '2025-08-07 20:46:05', '2025-08-08 01:46:05'),
(57, 'Juan Fernando Urrego', 'juan', 'admin123', 'Vendedor', 'vistas/img/usuarios/juan/461.jpg', 1, '2018-02-06 16:58:50', '2025-08-07 23:39:57'),
(58, 'Julio Gómez', 'julio', 'Julio123', 'Especial', 'vistas/img/usuarios/julio/100.png', 1, '2025-08-07 19:56:28', '2025-08-08 00:56:28'),
(59, 'Ana Gonzalez', 'ana', 'ana123', 'Vendedor', 'vistas/img/usuarios/ana/260.png', 1, '2017-12-26 19:21:40', '2025-08-07 23:40:35'),
(60, 'Jeremy Lima', 'Jeremy', '123', 'Administrador', '', 1, '0000-00-00 00:00:00', '2025-08-08 01:35:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `codigo` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_vendedor` int(11) NOT NULL,
  `productos` text COLLATE utf8_spanish_ci NOT NULL,
  `impuesto` float NOT NULL,
  `neto` float NOT NULL,
  `total` float NOT NULL,
  `metodo_pago` text COLLATE utf8_spanish_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `codigo`, `id_cliente`, `id_vendedor`, `productos`, `impuesto`, `neto`, `total`, `metodo_pago`, `fecha`) VALUES
(17, 10001, 3, 1, '[{\"id\":\"1\",\"descripcion\":\"Aspiradora Industrial \",\"cantidad\":\"2\",\"stock\":\"13\",\"precio\":\"1200\",\"total\":\"2400\"},{\"id\":\"2\",\"descripcion\":\"Plato Flotante para Allanadora\",\"cantidad\":\"2\",\"stock\":\"7\",\"precio\":\"6300\",\"total\":\"12600\"},{\"id\":\"3\",\"descripcion\":\"Compresor de Aire para pintura\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"4200\",\"total\":\"4200\"}]', 3648, 19200, 22848, 'Efectivo', '2018-02-02 01:11:04'),
(18, 10002, 4, 59, '[{\"id\":\"5\",\"descripcion\":\"Cortadora de Piso sin Disco \",\"cantidad\":\"2\",\"stock\":\"18\",\"precio\":\"2156\",\"total\":\"4312\"},{\"id\":\"4\",\"descripcion\":\"Cortadora de Adobe sin Disco \",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"5600\",\"total\":\"5600\"},{\"id\":\"6\",\"descripcion\":\"Disco Punta Diamante \",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"1540\",\"total\":\"1540\"},{\"id\":\"7\",\"descripcion\":\"Extractor de Aire \",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"2156\",\"total\":\"2156\"}]', 2585.52, 13608, 16193.5, 'TC-34346346346', '2018-02-02 14:57:20'),
(19, 10003, 5, 59, '[{\"id\":\"8\",\"descripcion\":\"Guadañadora \",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"2156\",\"total\":\"2156\"},{\"id\":\"9\",\"descripcion\":\"Hidrolavadora Eléctrica \",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"3640\",\"total\":\"3640\"},{\"id\":\"7\",\"descripcion\":\"Extractor de Aire \",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"2156\",\"total\":\"2156\"}]', 1510.88, 7952, 9462.88, 'Efectivo', '2018-01-18 14:57:40'),
(20, 10004, 5, 59, '[{\"id\":\"3\",\"descripcion\":\"Compresor de Aire para pintura\",\"cantidad\":\"5\",\"stock\":\"14\",\"precio\":\"4200\",\"total\":\"21000\"},{\"id\":\"4\",\"descripcion\":\"Cortadora de Adobe sin Disco \",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"5600\",\"total\":\"5600\"},{\"id\":\"5\",\"descripcion\":\"Cortadora de Piso sin Disco \",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"2156\",\"total\":\"2156\"}]', 5463.64, 28756, 34219.6, 'TD-454475467567', '2018-01-25 14:58:09'),
(21, 10005, 6, 57, '[{\"id\":\"4\",\"descripcion\":\"Cortadora de Adobe sin Disco \",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"5600\",\"total\":\"5600\"},{\"id\":\"5\",\"descripcion\":\"Cortadora de Piso sin Disco \",\"cantidad\":\"1\",\"stock\":\"16\",\"precio\":\"2156\",\"total\":\"2156\"},{\"id\":\"3\",\"descripcion\":\"Compresor de Aire para pintura\",\"cantidad\":\"5\",\"stock\":\"9\",\"precio\":\"4200\",\"total\":\"21000\"}]', 5463.64, 28756, 34219.6, 'TC-6756856867', '2018-01-09 14:59:07'),
(22, 10006, 10, 1, '[{\"id\":\"3\",\"descripcion\":\"Compresor de Aire para pintura\",\"cantidad\":\"1\",\"stock\":\"8\",\"precio\":\"4200\",\"total\":\"4200\"},{\"id\":\"4\",\"descripcion\":\"Cortadora de Adobe sin Disco \",\"cantidad\":\"1\",\"stock\":\"16\",\"precio\":\"5600\",\"total\":\"5600\"},{\"id\":\"5\",\"descripcion\":\"Cortadora de Piso sin Disco \",\"cantidad\":\"3\",\"stock\":\"13\",\"precio\":\"2156\",\"total\":\"6468\"},{\"id\":\"6\",\"descripcion\":\"Disco Punta Diamante \",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"1540\",\"total\":\"1540\"}]', 3383.52, 17808, 21191.5, 'Efectivo', '2018-01-26 15:03:22'),
(23, 10007, 9, 1, '[{\"id\":\"6\",\"descripcion\":\"Disco Punta Diamante \",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"1540\",\"total\":\"1540\"},{\"id\":\"7\",\"descripcion\":\"Extractor de Aire \",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"2156\",\"total\":\"2156\"},{\"id\":\"8\",\"descripcion\":\"Guadañadora \",\"cantidad\":\"6\",\"stock\":\"13\",\"precio\":\"2156\",\"total\":\"12936\"},{\"id\":\"9\",\"descripcion\":\"Hidrolavadora Eléctrica \",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"3640\",\"total\":\"3640\"}]', 3851.68, 20272, 24123.7, 'TC-357547467346', '2017-11-30 15:03:53'),
(24, 10008, 12, 1, '[{\"id\":\"2\",\"descripcion\":\"Plato Flotante para Allanadora\",\"cantidad\":\"1\",\"stock\":\"6\",\"precio\":\"6300\",\"total\":\"6300\"},{\"id\":\"7\",\"descripcion\":\"Extractor de Aire \",\"cantidad\":\"5\",\"stock\":\"12\",\"precio\":\"2156\",\"total\":\"10780\"},{\"id\":\"6\",\"descripcion\":\"Disco Punta Diamante \",\"cantidad\":\"1\",\"stock\":\"16\",\"precio\":\"1540\",\"total\":\"1540\"},{\"id\":\"9\",\"descripcion\":\"Hidrolavadora Eléctrica \",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"3640\",\"total\":\"3640\"}]', 4229.4, 22260, 26489.4, 'TD-35745575', '2017-12-25 15:04:11'),
(25, 10009, 11, 1, '[{\"id\":\"10\",\"descripcion\":\"Hidrolavadora Gasolina\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"3094\",\"total\":\"3094\"},{\"id\":\"9\",\"descripcion\":\"Hidrolavadora Eléctrica \",\"cantidad\":\"1\",\"stock\":\"16\",\"precio\":\"3640\",\"total\":\"3640\"},{\"id\":\"6\",\"descripcion\":\"Disco Punta Diamante \",\"cantidad\":\"1\",\"stock\":\"15\",\"precio\":\"1540\",\"total\":\"1540\"}]', 1572.06, 8274, 9846.06, 'TD-5745745745', '2017-08-15 15:04:38'),
(26, 10010, 8, 1, '[{\"id\":\"9\",\"descripcion\":\"Hidrolavadora Eléctrica \",\"cantidad\":\"1\",\"stock\":\"15\",\"precio\":\"3640\",\"total\":\"3640\"},{\"id\":\"10\",\"descripcion\":\"Hidrolavadora Gasolina\",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"3094\",\"total\":\"3094\"}]', 1279.46, 6734, 8013.46, 'Efectivo', '2017-12-07 15:05:09'),
(27, 10011, 7, 1, '[{\"id\":\"60\",\"descripcion\":\"Cortadora de Baldosin\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"1302\",\"total\":\"1302\"},{\"id\":\"59\",\"descripcion\":\"Cono slump\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"196\",\"total\":\"196\"},{\"id\":\"58\",\"descripcion\":\"Coche llanta neumatica\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"588\",\"total\":\"588\"},{\"id\":\"57\",\"descripcion\":\"Cizalla de Tijera\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"812\",\"total\":\"812\"}]', 550.62, 2898, 3448.62, 'Efectivo', '2017-12-25 22:23:38'),
(28, 10012, 12, 57, '[{\"id\":\"59\",\"descripcion\":\"Cono slump\",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"196\",\"total\":\"196\"},{\"id\":\"58\",\"descripcion\":\"Coche llanta neumatica\",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"588\",\"total\":\"588\"},{\"id\":\"54\",\"descripcion\":\"Chapeta\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"924\",\"total\":\"924\"},{\"id\":\"53\",\"descripcion\":\"Bomba Hidrostatica\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"1078\",\"total\":\"1078\"}]', 529.34, 2786, 3315.34, 'TC-3545235235', '2017-12-25 22:24:24'),
(29, 10013, 11, 57, '[{\"id\":\"54\",\"descripcion\":\"Chapeta\",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"924\",\"total\":\"924\"},{\"id\":\"59\",\"descripcion\":\"Cono slump\",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"196\",\"total\":\"196\"},{\"id\":\"60\",\"descripcion\":\"Cortadora de Baldosin\",\"cantidad\":\"5\",\"stock\":\"14\",\"precio\":\"1302\",\"total\":\"6510\"}]', 1449.7, 7630, 9079.7, 'TC-425235235235', '2017-12-26 22:24:50'),
(30, 10014, 10, 57, '[{\"id\":\"59\",\"descripcion\":\"Cono slump\",\"cantidad\":\"1\",\"stock\":\"16\",\"precio\":\"196\",\"total\":\"196\"},{\"id\":\"54\",\"descripcion\":\"Chapeta\",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"924\",\"total\":\"924\"},{\"id\":\"53\",\"descripcion\":\"Bomba Hidrostatica\",\"cantidad\":\"10\",\"stock\":\"9\",\"precio\":\"1078\",\"total\":\"10780\"}]', 2261, 11900, 14161, 'Efectivo', '2017-12-26 22:25:09'),
(31, 10015, 9, 57, '[{\"id\":\"57\",\"descripcion\":\"Cizalla de Tijera\",\"cantidad\":\"3\",\"stock\":\"16\",\"precio\":\"812\",\"total\":\"2436\"}]', 462.84, 2436, 2898.84, 'Efectivo', '2017-12-26 22:25:33'),
(32, 10016, 8, 57, '[{\"id\":\"58\",\"descripcion\":\"Coche llanta neumatica\",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"588\",\"total\":\"588\"},{\"id\":\"57\",\"descripcion\":\"Cizalla de Tijera\",\"cantidad\":\"5\",\"stock\":\"11\",\"precio\":\"812\",\"total\":\"4060\"},{\"id\":\"56\",\"descripcion\":\"Cizalla de Palanca\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"630\",\"total\":\"630\"}]', 1002.82, 5278, 6280.82, 'TD-4523523523', '2017-12-26 22:25:55'),
(33, 10017, 7, 57, '[{\"id\":\"57\",\"descripcion\":\"Cizalla de Tijera\",\"cantidad\":\"4\",\"stock\":\"7\",\"precio\":\"812\",\"total\":\"3248\"},{\"id\":\"52\",\"descripcion\":\"Bascula \",\"cantidad\":\"3\",\"stock\":\"17\",\"precio\":\"182\",\"total\":\"546\"},{\"id\":\"55\",\"descripcion\":\"Cilindro muestra de concreto\",\"cantidad\":\"2\",\"stock\":\"18\",\"precio\":\"560\",\"total\":\"1120\"},{\"id\":\"56\",\"descripcion\":\"Cizalla de Palanca\",\"cantidad\":\"1\",\"stock\":\"18\",\"precio\":\"630\",\"total\":\"630\"}]', 1053.36, 5544, 6597.36, 'Efectivo', '2017-12-26 22:26:28'),
(34, 10018, 6, 57, '[{\"id\":\"51\",\"descripcion\":\"Tensor\",\"cantidad\":\"1\",\"stock\":\"19\",\"precio\":\"140\",\"total\":\"140\"},{\"id\":\"52\",\"descripcion\":\"Bascula \",\"cantidad\":\"5\",\"stock\":\"12\",\"precio\":\"182\",\"total\":\"910\"},{\"id\":\"53\",\"descripcion\":\"Bomba Hidrostatica\",\"cantidad\":\"1\",\"stock\":\"8\",\"precio\":\"1078\",\"total\":\"1078\"}]', 404.32, 2128, 2532.32, 'Efectivo', '2017-12-26 22:26:51'),
(35, 10019, 5, 57, '[{\"id\":\"56\",\"descripcion\":\"Cizalla de Palanca\",\"cantidad\":\"15\",\"stock\":\"3\",\"precio\":\"630\",\"total\":\"9450\"},{\"id\":\"55\",\"descripcion\":\"Cilindro muestra de concreto\",\"cantidad\":\"1\",\"stock\":\"17\",\"precio\":\"560\",\"total\":\"560\"}]', 1901.9, 10010, 11911.9, 'Efectivo', '2017-12-26 22:27:13'),
(36, 10020, 4, 57, '[{\"id\":\"55\",\"descripcion\":\"Cilindro muestra de concreto\",\"cantidad\":\"1\",\"stock\":\"16\",\"precio\":\"560\",\"total\":\"560\"},{\"id\":\"54\",\"descripcion\":\"Chapeta\",\"cantidad\":\"1\",\"stock\":\"16\",\"precio\":\"924\",\"total\":\"924\"}]', 281.96, 1484, 1765.96, 'TC-46346346346', '2017-12-26 22:27:42'),
(37, 10021, 3, 1, '[{\"id\":\"60\",\"descripcion\":\"Cortadora de Baldosin\",\"cantidad\":\"1\",\"stock\":\"13\",\"precio\":\"1302\",\"total\":\"1302\"},{\"id\":\"59\",\"descripcion\":\"Cono slump\",\"cantidad\":\"1\",\"stock\":\"15\",\"precio\":\"196\",\"total\":\"196\"}]', 149.8, 1498, 1647.8, 'Efectivo', '2018-02-06 22:47:02');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
